export default function Bookmarks(){return(<div><h2>Bookmarks</h2><p>You haven't bookmarked anything yet.</p></div>);}
