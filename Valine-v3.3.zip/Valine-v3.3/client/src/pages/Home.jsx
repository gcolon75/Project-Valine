export default function Home(){return(<div className='card'><h2>Welcome to Valine v3.2</h2><p>Discover talent, scripts and opportunities.</p></div>);}
