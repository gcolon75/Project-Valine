# Valine v3.2
This version adds comment threads, messages, notifications, bookmarks, settings and auditions. All pages have shells ready for implementation with real data later.
