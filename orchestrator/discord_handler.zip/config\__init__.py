"""Configuration module for orchestrator."""
