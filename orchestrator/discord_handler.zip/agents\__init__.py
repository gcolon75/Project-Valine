"""
Multi-agent orchestration module.
Provides agent registry and routing capabilities.
"""
